#! /bin/bash
echo -n "Do you want to build an Oxide plug-in environment by automatic processing? [Y/n]:"
read ANS

case $ANS in
    "" | [Yy]* )
        echo "Stop the Rust server"
        systemctl stop rust-server;
        echo "Rust server stopped"
        echo "Update with SteamCMD"
        /usr/games/steamcmd +login anonymous +force_install_dir /home/steam/rust_server +app_update 258550 validate +quit;
        echo "Update work by SteamCMD is completed"
        echo "Install the library (unzip) required to unzip the zip file"
        sudo apt install -y unzip;
        echo "Installation of the library (unzip) required to unzip the zip file is complete"
        echo "Start downloading and unzipping Oxide"
        cd /home/steam/rust_server;
        wget https://umod.org/games/rust/download/develop -O oxide.zip;
        unzip -o oxide.zip;
        rm oxide.zip;
        echo "Downloading and unzipping Oxide is Complete"
        chown -R steam:steam /home/steam/rust_server;
        echo "Start the Rust server."
        systemctl start rust-server;
        journalctl -e -f -u rust-server;
        ;;
    * )
        echo "Quit the Rust update program"
        ;;
esac